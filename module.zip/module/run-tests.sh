#!/bin/sh

python -m unittest discover -s tests/
