#!/usr/bin/env sh

# will be called on docker build process
# Here you can install packages like nmap
#apk add nmap
